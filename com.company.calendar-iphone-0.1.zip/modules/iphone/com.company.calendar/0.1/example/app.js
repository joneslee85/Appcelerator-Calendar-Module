// open a single window
var win = Ti.UI.createWindow({
	backgroundColor:'white'
});

// load the module
//var Calendar = require('com.company.calendar');

// Print out the debug message if you are unsure
//Ti.API.info("module is => " + Calendar);

//var calendarView = Calendar.createView({
//  top:0
  /*headerColor: "red",
  calendarColor: "#aaa8a8"*/
  //});

// dateSelected event handler
//calendarView.addEventListener('dateSelected', function(e) {
//  try {
    // Do something with the date
//  } catch(e) {
//    Ti.API.info(e);
//  }
//});

//calendarView.show();
//win.add(calendarView);
win.open();